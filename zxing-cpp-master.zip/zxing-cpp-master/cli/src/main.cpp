#include<iostream>
#include<string>
#include "opencv2/opencv.hpp"
#include "zxingdecoder.h"
#include "opencvbitmapsource.h"

using namespace std;
using namespace zxing;
using namespace zxing::multi;
using namespace zxing::qrcode;
using namespace cv;

void hMirrorTrans(const cv::Mat &src, cv::Mat &dst)
{
    CV_Assert(src.depth() == CV_8U);
    dst.create(src.rows, src.cols, src.type());

    int rows = src.rows;
    int cols = src.cols;

    switch (src.channels())
    {
    case 1:
        const uchar *origal;
        uchar *p;
        for (int i = 0; i < rows; i++){
            origal = src.ptr<uchar>(i);
            p = dst.ptr<uchar>(i);
            for (int j = 0; j < cols; j++){
                p[j] = origal[cols - 1 - j];
            }
        }
        break;
    case 3:
        const cv::Vec3b *origal3;
        cv::Vec3b *p3;
        for (int i = 0; i < rows; i++) {
            origal3 = src.ptr<cv::Vec3b>(i);
            p3 = dst.ptr<cv::Vec3b>(i);
            for(int j = 0; j < cols; j++){
                p3[j] = origal3[cols - 1 - j];
            }
        }
        break;
    default:
        break;
    }

}

int main()
{
 Mat image;
 ZxingDecoder zxingDecoder;
 VideoCapture capture(0);
 capture >> image;
 namedWindow("image",WINDOW_AUTOSIZE);
string str;
Mat NewImage;
 while(!image.empty())
 {
hMirrorTrans(image,NewImage);//����ͷ��ȡ����ͼƬ�������෴�ģ����Խ�ͼƬ�������ҵ����õ�������ͼ�� 
  str=zxingDecoder.decode(NewImage);
  if(str.size()!=0)
  {
     cout<<"result="<<str.data()<<endl;
	break;
  }
  imshow("image",NewImage);
  waitKey(10);
  capture >>image;
 }
	cout<<"Get and decode:"<<str<<endl;
return 0;
}
