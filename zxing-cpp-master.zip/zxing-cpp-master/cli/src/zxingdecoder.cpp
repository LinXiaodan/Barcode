#include "zxingdecoder.h"



ZxingDecoder::ZxingDecoder()
{
}

ZxingDecoder::~ZxingDecoder()
{
}

/* 
string ZxingDecoder::decode(const std::string& filename)
{
	Ref<LuminanceSource> source;
	string result;
	try 
	{
		source = ImageReaderSource::create(filename);
	}
	catch (const zxing::IllegalArgumentException &e)
	{
		cerr << e.what() << " (ignoring)" << endl;
		return string();
	}
	result = decodeImage(source);
	return result;
}
*/


string ZxingDecoder::decode(cv::Mat& image)
{
	cv::Mat gray;
	if(image.channels() != 1)
	{
		cv::cvtColor(image, gray, CV_BGR2GRAY);
	}
	else
	{
		gray = image.clone();
	}
	Ref<OpenCVBitmapSource> source(new OpenCVBitmapSource(gray));
	return decodeImage(source);
}

/* 
string ZxingDecoder::decodeImage(Ref<LuminanceSource>& source)
{
	Ref<Result> result;
	int errorRes = -1;
	string cell_result;
	try
	{
		Ref<Binarizer> binarizer;
		binarizer = new GlobalHistogramBinarizer(source);
		DecodeHints hints(DecodeHints::DEFAULT_HINT);
		hints.setTryHarder(true);
		Ref<BinaryBitmap> binary(new BinaryBitmap(binarizer));
		Ref<Reader> reader(new MultiFormatReader);
		result = reader->decode(binary, hints);
		errorRes = 0;
	}
	catch (const ReaderException& e)
	{
		cell_result = "zxing::ReaderException: " + string(e.what());
		errorRes = -2;
	} catch (const zxing::IllegalArgumentException& e)
	{
		cell_result = "zxing::IllegalArgumentException: " + string(e.what());
		errorRes = -3;
	} catch (const zxing::Exception& e)
	{
		cell_result = "zxing::Exception: " + string(e.what());
		errorRes = -4;
	} catch (const std::exception& e)
	{
		cell_result = "std::exception: " + string(e.what());
		errorRes = -5;
	}
	//convert string format from utf-8 to gb2312
	const char* data = result->getText()->getText().data();
	char* gb2312 = CodeFormatConvert::convertUTF8ToGB2312(data);
	return std::string(gb2312);
}
*/


string ZxingDecoder::decodeImage(Ref<OpenCVBitmapSource>& source)
{
	Ref<Binarizer> binarizer(new GlobalHistogramBinarizer(source));
	Ref<BinaryBitmap> bitmap(new BinaryBitmap(binarizer));
	MultiFormatReader reader;
	Ref<Result> result;
	try
	{
		result = reader.decode(bitmap, DecodeHints(DecodeHints::TRYHARDER_HINT));
	}
	catch(const std::exception& e)
	{
		std::cerr<<e.what()<<std::endl;
		return string();
	}
	return result->getText()->getText();
}